# Use the 'File' menu above to 'Save' after pasting in your own mm_shared function definition.
import numpy as np
from numba import cuda, types
@cuda.jit
def mm_shared(a, b, c):
    x, y = cuda.grid(2)
    sum = 0
    
    tx = cuda.threadIdx.x
    ty = cuda.threadIdx.y
    bpg = cuda.gridDim.x 
    # `a_cache` and `b_cache` are already correctly defined
    a_cache = cuda.shared.array(block_size, types.int32)
    b_cache = cuda.shared.array(block_size, types.int32)
    
    for i in range(bpg):
        # Preload data into shared memory
        a_cache[tx, ty] = a[x, ty + i * block_size[0]]
        b_cache[tx, ty] = b[tx + i * block_size[0], y]

        # Wait until all threads finish preloading
        cuda.syncthreads()

        # Computes partial product on the shared memory
        for j in range(block_size[0]):
            sum += a_cache[tx, j] * b_cache[j, ty]

        # Wait until all threads finish computing
        cuda.syncthreads()

    c[x, y] = sum